--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2 (Debian 12.2-2.pgdg100+1)
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE gko;
--
-- Name: gko; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE gko WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE gko OWNER TO postgres;

\connect gko

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ocorrencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ocorrencia (
    ocorrencia_id bigint NOT NULL,
    ocorrencia_data timestamp(0) without time zone,
    ocorrencia_comentario character varying(255),
    ocorrencia_codigo integer,
    ocorrencia_nome character varying(255),
    embarque_id integer,
    embarque_numero bigint,
    embarque_data_criacao timestamp(0) without time zone,
    embarque_data_emissao timestamp(0) without time zone,
    embarque_data_embarque timestamp(0) without time zone,
    embarque_data_previsao timestamp(0) without time zone,
    embarque_status character varying(100),
    destinatario_id integer,
    destinatario_nome character varying(255),
    destinatario_cnpj character varying(20),
    destinatario_celular character varying(20),
    destinatario_cidade character varying(50),
    destinatario_uf character varying(2),
    destinatario_endereco_id integer,
    transportadora_id integer,
    transportadora_cnpj character varying(20),
    transportadora_nome character varying(255),
    pedido_id integer,
    pedido_numero character varying(100),
    pedido_data_emissao timestamp(0) without time zone,
    pedido_data_criacao timestamp(0) without time zone,
    pedido_data_agendamento timestamp(0) without time zone,
    embarcador_id integer,
    embarcador_cnpj character varying(20),
    embarcador_nome character varying(100),
    entrega_id integer,
    entrega_data_criacao timestamp(0) without time zone,
    entrega_data_entrega timestamp(0) without time zone
);


ALTER TABLE public.ocorrencia OWNER TO postgres;

--
-- Name: token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token (
    id integer NOT NULL,
    token text NOT NULL
);
ALTER TABLE ONLY public.token ALTER COLUMN id SET STATISTICS 0;
ALTER TABLE ONLY public.token ALTER COLUMN token SET STATISTICS 0;


ALTER TABLE public.token OWNER TO postgres;

--
-- Name: token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.token_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_id_seq OWNER TO postgres;

--
-- Name: token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.token_id_seq OWNED BY public.token.id;


--
-- Name: token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token ALTER COLUMN id SET DEFAULT nextval('public.token_id_seq'::regclass);


--
-- Data for Name: ocorrencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ocorrencia (ocorrencia_id, ocorrencia_data, ocorrencia_comentario, ocorrencia_codigo, ocorrencia_nome, embarque_id, embarque_numero, embarque_data_criacao, embarque_data_emissao, embarque_data_embarque, embarque_data_previsao, embarque_status, destinatario_id, destinatario_nome, destinatario_cnpj, destinatario_celular, destinatario_cidade, destinatario_uf, destinatario_endereco_id, transportadora_id, transportadora_cnpj, transportadora_nome, pedido_id, pedido_numero, pedido_data_emissao, pedido_data_criacao, pedido_data_agendamento, embarcador_id, embarcador_cnpj, embarcador_nome, entrega_id, entrega_data_criacao, entrega_data_entrega) FROM stdin;
\.
COPY public.ocorrencia (ocorrencia_id, ocorrencia_data, ocorrencia_comentario, ocorrencia_codigo, ocorrencia_nome, embarque_id, embarque_numero, embarque_data_criacao, embarque_data_emissao, embarque_data_embarque, embarque_data_previsao, embarque_status, destinatario_id, destinatario_nome, destinatario_cnpj, destinatario_celular, destinatario_cidade, destinatario_uf, destinatario_endereco_id, transportadora_id, transportadora_cnpj, transportadora_nome, pedido_id, pedido_numero, pedido_data_emissao, pedido_data_criacao, pedido_data_agendamento, embarcador_id, embarcador_cnpj, embarcador_nome, entrega_id, entrega_data_criacao, entrega_data_entrega) FROM '$$PATH$$/2930.dat';

--
-- Data for Name: token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token (id, token) FROM stdin;
\.
COPY public.token (id, token) FROM '$$PATH$$/2929.dat';

--
-- Name: token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.token_id_seq', 6, true);


--
-- Name: ocorrencia ocorrencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocorrencia
    ADD CONSTRAINT ocorrencia_pkey PRIMARY KEY (ocorrencia_id);


--
-- Name: token token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token
    ADD CONSTRAINT token_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

